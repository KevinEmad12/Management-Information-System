﻿
namespace ProjectMIS
{
    partial class Window3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Window3));
            this.Namelabel1 = new System.Windows.Forms.Label();
            this.Usernamelabel2 = new System.Windows.Forms.Label();
            this.Emaillabel3 = new System.Windows.Forms.Label();
            this.Passwordlabel4 = new System.Windows.Forms.Label();
            this.PhoneNolabel6 = new System.Windows.Forms.Label();
            this.Addresslabel7 = new System.Windows.Forms.Label();
            this.DOBlabel8 = new System.Windows.Forms.Label();
            this.Genderlabel9 = new System.Windows.Forms.Label();
            this.FradioButton1 = new System.Windows.Forms.RadioButton();
            this.MradioButton2 = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.SIGNUPbutton1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Namelabel1
            // 
            this.Namelabel1.AutoSize = true;
            this.Namelabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelabel1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Namelabel1.Location = new System.Drawing.Point(53, 34);
            this.Namelabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Namelabel1.Name = "Namelabel1";
            this.Namelabel1.Size = new System.Drawing.Size(51, 16);
            this.Namelabel1.TabIndex = 7;
            this.Namelabel1.Text = "Name:";
            // 
            // Usernamelabel2
            // 
            this.Usernamelabel2.AutoSize = true;
            this.Usernamelabel2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Usernamelabel2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Usernamelabel2.Location = new System.Drawing.Point(52, 127);
            this.Usernamelabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Usernamelabel2.Name = "Usernamelabel2";
            this.Usernamelabel2.Size = new System.Drawing.Size(81, 16);
            this.Usernamelabel2.TabIndex = 8;
            this.Usernamelabel2.Text = "Username:";
            // 
            // Emaillabel3
            // 
            this.Emaillabel3.AutoSize = true;
            this.Emaillabel3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emaillabel3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Emaillabel3.Location = new System.Drawing.Point(54, 93);
            this.Emaillabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Emaillabel3.Name = "Emaillabel3";
            this.Emaillabel3.Size = new System.Drawing.Size(49, 16);
            this.Emaillabel3.TabIndex = 9;
            this.Emaillabel3.Text = "Email:";
            // 
            // Passwordlabel4
            // 
            this.Passwordlabel4.AutoSize = true;
            this.Passwordlabel4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Passwordlabel4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Passwordlabel4.Location = new System.Drawing.Point(52, 159);
            this.Passwordlabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Passwordlabel4.Name = "Passwordlabel4";
            this.Passwordlabel4.Size = new System.Drawing.Size(79, 16);
            this.Passwordlabel4.TabIndex = 10;
            this.Passwordlabel4.Text = "Password:";
            this.Passwordlabel4.Click += new System.EventHandler(this.Passwordlabel4_Click);
            // 
            // PhoneNolabel6
            // 
            this.PhoneNolabel6.AutoSize = true;
            this.PhoneNolabel6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNolabel6.ForeColor = System.Drawing.SystemColors.Desktop;
            this.PhoneNolabel6.Location = new System.Drawing.Point(54, 188);
            this.PhoneNolabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.PhoneNolabel6.Name = "PhoneNolabel6";
            this.PhoneNolabel6.Size = new System.Drawing.Size(111, 16);
            this.PhoneNolabel6.TabIndex = 12;
            this.PhoneNolabel6.Text = "Phone Number:";
            // 
            // Addresslabel7
            // 
            this.Addresslabel7.AutoSize = true;
            this.Addresslabel7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Addresslabel7.Location = new System.Drawing.Point(53, 241);
            this.Addresslabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Addresslabel7.Name = "Addresslabel7";
            this.Addresslabel7.Size = new System.Drawing.Size(70, 16);
            this.Addresslabel7.TabIndex = 13;
            this.Addresslabel7.Text = "Address:";
            // 
            // DOBlabel8
            // 
            this.DOBlabel8.AutoSize = true;
            this.DOBlabel8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOBlabel8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.DOBlabel8.Location = new System.Drawing.Point(52, 65);
            this.DOBlabel8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.DOBlabel8.Name = "DOBlabel8";
            this.DOBlabel8.Size = new System.Drawing.Size(97, 16);
            this.DOBlabel8.TabIndex = 14;
            this.DOBlabel8.Text = "Date of Birth:";
            // 
            // Genderlabel9
            // 
            this.Genderlabel9.AutoSize = true;
            this.Genderlabel9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Genderlabel9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Genderlabel9.Location = new System.Drawing.Point(54, 214);
            this.Genderlabel9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Genderlabel9.Name = "Genderlabel9";
            this.Genderlabel9.Size = new System.Drawing.Size(62, 16);
            this.Genderlabel9.TabIndex = 15;
            this.Genderlabel9.Text = "Gender:";
            // 
            // FradioButton1
            // 
            this.FradioButton1.AutoSize = true;
            this.FradioButton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FradioButton1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.FradioButton1.Location = new System.Drawing.Point(126, 212);
            this.FradioButton1.Margin = new System.Windows.Forms.Padding(2);
            this.FradioButton1.Name = "FradioButton1";
            this.FradioButton1.Size = new System.Drawing.Size(74, 20);
            this.FradioButton1.TabIndex = 16;
            this.FradioButton1.TabStop = true;
            this.FradioButton1.Text = "Female";
            this.FradioButton1.UseVisualStyleBackColor = true;
            this.FradioButton1.CheckedChanged += new System.EventHandler(this.FradioButton1_CheckedChanged);
            // 
            // MradioButton2
            // 
            this.MradioButton2.AutoSize = true;
            this.MradioButton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MradioButton2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.MradioButton2.Location = new System.Drawing.Point(204, 212);
            this.MradioButton2.Margin = new System.Windows.Forms.Padding(2);
            this.MradioButton2.Name = "MradioButton2";
            this.MradioButton2.Size = new System.Drawing.Size(58, 20);
            this.MradioButton2.TabIndex = 17;
            this.MradioButton2.TabStop = true;
            this.MradioButton2.Text = "Male";
            this.MradioButton2.UseVisualStyleBackColor = true;
            this.MradioButton2.CheckedChanged += new System.EventHandler(this.MradioButton2_CheckedChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(146, 65);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.MinDate = new System.DateTime(1950, 1, 1, 0, 0, 0, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(189, 20);
            this.dateTimePicker1.TabIndex = 18;
            this.dateTimePicker1.Value = new System.DateTime(2010, 12, 31, 0, 0, 0, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(104, 34);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(231, 19);
            this.textBox1.TabIndex = 19;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(104, 95);
            this.textBox3.Margin = new System.Windows.Forms.Padding(2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(231, 19);
            this.textBox3.TabIndex = 21;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(135, 126);
            this.textBox4.Margin = new System.Windows.Forms.Padding(2);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(204, 19);
            this.textBox4.TabIndex = 22;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(135, 159);
            this.textBox5.Margin = new System.Windows.Forms.Padding(2);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(155, 19);
            this.textBox5.TabIndex = 23;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(169, 187);
            this.textBox6.Margin = new System.Windows.Forms.Padding(2);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(176, 19);
            this.textBox6.TabIndex = 24;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(127, 240);
            this.textBox7.Margin = new System.Windows.Forms.Padding(2);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(189, 19);
            this.textBox7.TabIndex = 25;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // SIGNUPbutton1
            // 
            this.SIGNUPbutton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SIGNUPbutton1.Location = new System.Drawing.Point(251, 316);
            this.SIGNUPbutton1.Margin = new System.Windows.Forms.Padding(2);
            this.SIGNUPbutton1.Name = "SIGNUPbutton1";
            this.SIGNUPbutton1.Size = new System.Drawing.Size(98, 34);
            this.SIGNUPbutton1.TabIndex = 26;
            this.SIGNUPbutton1.Text = "SignUp";
            this.SIGNUPbutton1.UseVisualStyleBackColor = true;
            this.SIGNUPbutton1.Click += new System.EventHandler(this.SIGNUPbutton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(481, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(155, 161);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Window3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(24)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(602, 366);
            this.Controls.Add(this.SIGNUPbutton1);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.MradioButton2);
            this.Controls.Add(this.FradioButton1);
            this.Controls.Add(this.Genderlabel9);
            this.Controls.Add(this.DOBlabel8);
            this.Controls.Add(this.Addresslabel7);
            this.Controls.Add(this.PhoneNolabel6);
            this.Controls.Add(this.Passwordlabel4);
            this.Controls.Add(this.Emaillabel3);
            this.Controls.Add(this.Usernamelabel2);
            this.Controls.Add(this.Namelabel1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Window3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Window3";
            this.Load += new System.EventHandler(this.Window3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Namelabel1;
        private System.Windows.Forms.Label Usernamelabel2;
        private System.Windows.Forms.Label Emaillabel3;
        private System.Windows.Forms.Label Passwordlabel4;
        private System.Windows.Forms.Label PhoneNolabel6;
        private System.Windows.Forms.Label Addresslabel7;
        private System.Windows.Forms.Label DOBlabel8;
        private System.Windows.Forms.Label Genderlabel9;
        private System.Windows.Forms.RadioButton FradioButton1;
        private System.Windows.Forms.RadioButton MradioButton2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button SIGNUPbutton1;
    }
}