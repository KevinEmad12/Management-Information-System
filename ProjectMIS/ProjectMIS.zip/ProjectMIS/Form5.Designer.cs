﻿
namespace ProjectMIS
{
    partial class Window5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Addtocartbutton1 = new System.Windows.Forms.Button();
            this.Addtocartbutton2 = new System.Windows.Forms.Button();
            this.Addtocartbutton3 = new System.Windows.Forms.Button();
            this.Iphonelabel1 = new System.Windows.Forms.Label();
            this.Laptoplabel2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Addtocartbutton1
            // 
            this.Addtocartbutton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addtocartbutton1.Location = new System.Drawing.Point(10, 365);
            this.Addtocartbutton1.Name = "Addtocartbutton1";
            this.Addtocartbutton1.Size = new System.Drawing.Size(215, 39);
            this.Addtocartbutton1.TabIndex = 3;
            this.Addtocartbutton1.Text = "Add to cart";
            this.Addtocartbutton1.UseVisualStyleBackColor = true;
            this.Addtocartbutton1.Click += new System.EventHandler(this.Addtocartbutton1_Click);
            // 
            // Addtocartbutton2
            // 
            this.Addtocartbutton2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addtocartbutton2.Location = new System.Drawing.Point(337, 367);
            this.Addtocartbutton2.Name = "Addtocartbutton2";
            this.Addtocartbutton2.Size = new System.Drawing.Size(215, 39);
            this.Addtocartbutton2.TabIndex = 4;
            this.Addtocartbutton2.Text = "Add to cart";
            this.Addtocartbutton2.UseVisualStyleBackColor = true;
            this.Addtocartbutton2.Click += new System.EventHandler(this.Addtocartbutton2_Click);
            // 
            // Addtocartbutton3
            // 
            this.Addtocartbutton3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addtocartbutton3.Location = new System.Drawing.Point(658, 365);
            this.Addtocartbutton3.Name = "Addtocartbutton3";
            this.Addtocartbutton3.Size = new System.Drawing.Size(215, 39);
            this.Addtocartbutton3.TabIndex = 5;
            this.Addtocartbutton3.Text = "Add to cart";
            this.Addtocartbutton3.UseVisualStyleBackColor = true;
            this.Addtocartbutton3.Click += new System.EventHandler(this.Addtocartbutton3_Click);
            // 
            // Iphonelabel1
            // 
            this.Iphonelabel1.AutoSize = true;
            this.Iphonelabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Iphonelabel1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Iphonelabel1.Location = new System.Drawing.Point(28, 291);
            this.Iphonelabel1.Name = "Iphonelabel1";
            this.Iphonelabel1.Size = new System.Drawing.Size(184, 60);
            this.Iphonelabel1.TabIndex = 8;
            this.Iphonelabel1.Text = "Iphone 14 pro 128 GB\r\nSpace grey color \r\n50000 L.E";
            this.Iphonelabel1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Laptoplabel2
            // 
            this.Laptoplabel2.AutoSize = true;
            this.Laptoplabel2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Laptoplabel2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Laptoplabel2.Location = new System.Drawing.Point(370, 281);
            this.Laptoplabel2.Name = "Laptoplabel2";
            this.Laptoplabel2.Size = new System.Drawing.Size(140, 80);
            this.Laptoplabel2.TabIndex = 9;
            this.Laptoplabel2.Text = "Lenovo IdeaPad\r\n8GB RAM \r\nSSD\r\n30000 L.E\r\n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(699, 289);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 60);
            this.label3.TabIndex = 10;
            this.label3.Text = "Beats Headphone \r\nBlack Color\r\n5500 L.E\r\n";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjectMIS.Properties.Resources.Headphones_Transparent_PNGeditedddd4;
            this.pictureBox3.Location = new System.Drawing.Point(709, 66);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(120, 176);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjectMIS.Properties.Resources.iPhone_14_PNG_Transparent__2_;
            this.pictureBox2.Location = new System.Drawing.Point(31, 66);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(152, 174);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectMIS.Properties.Resources._852_8528874_shop_our_experts_love_range_of_lenovo_laptopsediteddd2;
            this.pictureBox1.Location = new System.Drawing.Point(313, 66);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(268, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Window5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(24)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(877, 503);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Laptoplabel2);
            this.Controls.Add(this.Iphonelabel1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Addtocartbutton3);
            this.Controls.Add(this.Addtocartbutton2);
            this.Controls.Add(this.Addtocartbutton1);
            this.Name = "Window5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Window5";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Addtocartbutton1;
        private System.Windows.Forms.Button Addtocartbutton2;
        private System.Windows.Forms.Button Addtocartbutton3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Iphonelabel1;
        private System.Windows.Forms.Label Laptoplabel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}