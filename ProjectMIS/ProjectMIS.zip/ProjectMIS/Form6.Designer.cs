﻿
namespace ProjectMIS
{
    partial class Window6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Addtocartbutton1 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Treadmilllabel1 = new System.Windows.Forms.Label();
            this.TennisRlabel2 = new System.Windows.Forms.Label();
            this.Gloveslabel3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Addtocartbutton1
            // 
            this.Addtocartbutton1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addtocartbutton1.Location = new System.Drawing.Point(15, 366);
            this.Addtocartbutton1.Name = "Addtocartbutton1";
            this.Addtocartbutton1.Size = new System.Drawing.Size(215, 39);
            this.Addtocartbutton1.TabIndex = 4;
            this.Addtocartbutton1.Text = "Add to cart";
            this.Addtocartbutton1.UseVisualStyleBackColor = true;
            this.Addtocartbutton1.Click += new System.EventHandler(this.Addtocartbutton1_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(335, 366);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(215, 39);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add to cart";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(649, 366);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(215, 39);
            this.button2.TabIndex = 6;
            this.button2.Text = "Add to cart";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Treadmilllabel1
            // 
            this.Treadmilllabel1.AutoSize = true;
            this.Treadmilllabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Treadmilllabel1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Treadmilllabel1.Location = new System.Drawing.Point(24, 287);
            this.Treadmilllabel1.Name = "Treadmilllabel1";
            this.Treadmilllabel1.Size = new System.Drawing.Size(217, 80);
            this.Treadmilllabel1.TabIndex = 9;
            this.Treadmilllabel1.Text = "Echelon Stride Auto-Fold \r\nConnected Treadmill\r\n25000 L.E\r\n\r\n";
            this.Treadmilllabel1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TennisRlabel2
            // 
            this.TennisRlabel2.AutoSize = true;
            this.TennisRlabel2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TennisRlabel2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.TennisRlabel2.Location = new System.Drawing.Point(345, 287);
            this.TennisRlabel2.Name = "TennisRlabel2";
            this.TennisRlabel2.Size = new System.Drawing.Size(194, 60);
            this.TennisRlabel2.TabIndex = 10;
            this.TennisRlabel2.Text = "Wilson Tennis Racket \r\nGreen and Black Color\r\n450 L.E";
            // 
            // Gloveslabel3
            // 
            this.Gloveslabel3.AutoSize = true;
            this.Gloveslabel3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gloveslabel3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.Gloveslabel3.Location = new System.Drawing.Point(682, 287);
            this.Gloveslabel3.Name = "Gloveslabel3";
            this.Gloveslabel3.Size = new System.Drawing.Size(132, 60);
            this.Gloveslabel3.TabIndex = 11;
            this.Gloveslabel3.Text = "Red and Black \r\nBoxing Gloves \r\n600 L.E";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::ProjectMIS.Properties.Resources.boxing_gloves_PNG10469edited;
            this.pictureBox3.Location = new System.Drawing.Point(657, 72);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(174, 174);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::ProjectMIS.Properties.Resources.Tennis_Racket_PNG_Transparent_Imagedited;
            this.pictureBox2.Location = new System.Drawing.Point(349, 72);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(174, 174);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ProjectMIS.Properties.Resources._182_1827413_tread_render_life_fitness_activate_treadmilledited;
            this.pictureBox1.Location = new System.Drawing.Point(37, 72);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(193, 174);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Window6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(228)))), ((int)(((byte)(30)))), ((int)(((byte)(24)))));
            this.ClientSize = new System.Drawing.Size(877, 503);
            this.Controls.Add(this.Gloveslabel3);
            this.Controls.Add(this.TennisRlabel2);
            this.Controls.Add(this.Treadmilllabel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Addtocartbutton1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Window6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Window6";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button Addtocartbutton1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Treadmilllabel1;
        private System.Windows.Forms.Label TennisRlabel2;
        private System.Windows.Forms.Label Gloveslabel3;
    }
}