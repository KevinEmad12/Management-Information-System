﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectMIS
{
    public partial class Window5 : Form
    {
        public Window5()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void Addtocartbutton3_Click(object sender, EventArgs e)
        {
            Window8 fm = new Window8();
            fm.Show();
        }

        private void Addtocartbutton2_Click(object sender, EventArgs e)
        {
            Window8 fm = new Window8();
            fm.Show();
        }

        private void Addtocartbutton1_Click(object sender, EventArgs e)
        {
            Window8 fm = new Window8();
            fm.Show();
        }
    }
}
